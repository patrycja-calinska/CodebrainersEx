
class PracticeFormTestData:
    def __init__(self):
        self.URL = "https://demoqa.com/automation-practice-form"
        self.EXCPECTED_SITE_TITLE = "DEMOQA"
        self.first_name = "Artur"
        self.last_name = "Babinski"
        self.email_address = "arczi@test.pl"

